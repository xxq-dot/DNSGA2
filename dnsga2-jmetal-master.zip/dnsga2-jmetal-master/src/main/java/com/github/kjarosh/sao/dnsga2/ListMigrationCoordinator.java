package com.github.kjarosh.sao.dnsga2;

import java.util.List;

/**
 * @author Kamil Jarosz
 */
public interface ListMigrationCoordinator<S> extends MigrationCoordinator<List<S>> {

}
